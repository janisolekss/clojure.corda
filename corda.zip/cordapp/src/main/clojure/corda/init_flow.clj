(ns corda.init-flow
  (:import (net.corda.core.utilities ProgressTracker$Step)))

(gen-class
  :name ^{net.corda.core.flows.StartableByRPC {}} corda.InitFlow
  :extends ^{:parameters [String]} net.corda.core.flows.FlowLogic)

(defn -getProgressTracker [] [(new ProgressTracker$Step "Cheering")])


(defn ^{co.paralleluniverse.fibers.Suspendable {}} -call []
  (println ("Hellow from Clojure"))
  "ReturnString")
